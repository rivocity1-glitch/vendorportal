import React, { useState, useEffect, useRef } from "react";
import { Eye, EyeOff, Zap, CheckCircle2 } from "lucide-react";
import { supabase } from "../../../lib/supabase";

interface RegisterProps {
  onNavigateToLogin: () => void;
}

export function Register({ onNavigateToLogin }: RegisterProps) {
  // Form State Handles
  const [shopName, setShopName] = useState("");
  const [ownerName, setOwnerName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [category, setCategory] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  // 5 Drug Licence Number States & Expiry
  const [drugLicenseNumber1, setDrugLicenseNumber1] = useState("");
  const [drugLicenseNumber2, setDrugLicenseNumber2] = useState("");
  const [drugLicenseNumber3, setDrugLicenseNumber3] = useState("");
  const [drugLicenseNumber4, setDrugLicenseNumber4] = useState("");
  const [drugLicenseNumber5, setDrugLicenseNumber5] = useState("");
  const [drugLicenseExpiry, setDrugLicenseExpiry] = useState("");

  // Dynamic Categories state
  const [categories, setCategories] = useState<any[]>([]);
  const [categoriesLoading, setCategoriesLoading] = useState(false);

  // Interface Utility States
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [showPremiumCard, setShowPremiumCard] = useState(false);

  // Form Field Refs for Auto-focus and Smooth Scrolling
  const shopNameRef = useRef<HTMLInputElement>(null);
  const ownerNameRef = useRef<HTMLInputElement>(null);
  const emailRef = useRef<HTMLInputElement>(null);
  const phoneRef = useRef<HTMLInputElement>(null);
  const categoryRef = useRef<HTMLSelectElement>(null);
  const addressRef = useRef<HTMLTextAreaElement>(null);
  const drugLicenseNumber1Ref = useRef<HTMLInputElement>(null);
  const drugLicenseExpiryRef = useRef<HTMLInputElement>(null);
  const passwordRef = useRef<HTMLInputElement>(null);
  const confirmPasswordRef = useRef<HTMLInputElement>(null);

  // Reference variables for tracking generated identifiers
  const [savedShopName, setSavedShopName] = useState("");
  const [savedPhone, setSavedPhone] = useState("");
  const [savedLicenseNumbers, setSavedLicenseNumbers] = useState("");

  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = async () => {
    setCategoriesLoading(true);
    const { data, error } = await supabase
      .from("product_categories")
      .select("id,name,requires_drug_license")
      .eq("status", "active")
      .order("display_order");

    if (!error && data) {
      setCategories(data);
    }
    setCategoriesLoading(false);
  };

  // Determine if the currently selected category requires a drug license
  const selectedCategoryObj = categories.find((cat) => String(cat.id) === String(category));
  const requiresDrugLicense = selectedCategoryObj ? !!selectedCategoryObj.requires_drug_license : false;

  // Clear drug license values if the category changes to one that does not require it
  useEffect(() => {
    if (!requiresDrugLicense) {
      setDrugLicenseNumber1("");
      setDrugLicenseNumber2("");
      setDrugLicenseNumber3("");
      setDrugLicenseNumber4("");
      setDrugLicenseNumber5("");
      setDrugLicenseExpiry("");
    }
  }, [category, requiresDrugLicense]);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return; // Prevent accidental double submission

    setError("");
    setSuccessMessage("");
    setShowPremiumCard(false);

    // Validation helper to manage focus, scrolling, and error handling
    const triggerValidationError = (message: string, inputRef: React.RefObject<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement | null>) => {
      setError(message);
      if (inputRef.current) {
        inputRef.current.focus();
        inputRef.current.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    };

    // 1. Validate All Required Fields (Removed shopScale)
    if (!shopName) return triggerValidationError("Please enter your Shop Name.", shopNameRef);
    if (!ownerName) return triggerValidationError("Please enter the Owner Name.", ownerNameRef);
    if (!email) return triggerValidationError("Please enter your Email Address.", emailRef);
    if (!phone) return triggerValidationError("Please enter your Phone Number.", phoneRef);
    if (!category) return triggerValidationError("Please select a Store Category.", categoryRef);
    if (!address) return triggerValidationError("Please enter your Physical Store Address.", addressRef);

    // Drug Licence Fields Validation if required
    if (requiresDrugLicense) {
      if (!drugLicenseNumber1.trim()) {
        return triggerValidationError("Primary Drug Licence Number is required for this category.", drugLicenseNumber1Ref);
      }
      if (!drugLicenseExpiry) {
        return triggerValidationError("Drug Licence Expiry Date is required for this category.", drugLicenseExpiryRef);
      }
    }

    if (!password) return triggerValidationError("Please create a password.", passwordRef);
    if (!confirmPassword) return triggerValidationError("Please confirm your password.", confirmPasswordRef);

    // 2. Validate Password Matching Criteria
    if (password !== confirmPassword) {
      return triggerValidationError("Passwords do not match. Please re-enter.", confirmPasswordRef);
    }

    if (password.length < 6) {
      return triggerValidationError("Password must be at least 6 characters long.", passwordRef);
    }

    setLoading(true);

    // Combine entered license numbers into a readable format for submission
    const licenseNumbersArray = [
      drugLicenseNumber1.trim(),
      drugLicenseNumber2.trim(),
      drugLicenseNumber3.trim(),
      drugLicenseNumber4.trim(),
      drugLicenseNumber5.trim()
    ].filter(Boolean);
    const combinedLicenseNumbers = licenseNumbersArray.join(", ");

    // Cache the active form inputs before clearing the form state
    const currentShopName = shopName;
    const currentPhone = phone;

    try {
      // 3. Provision the Core Supabase Auth Account
      console.log("Executing Step 1: Supabase Auth Sign Up for", email);
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: undefined
        }
      });

      if (authError) {
        console.error("Auth Sign-up Error trace:", authError);
        throw new Error(`Authentication setup failed: ${authError.message}`);
      }
      if (!authData?.user) throw new Error("Could not initialize authentication profile records.");

      // Generate a dynamic clean, pseudo-random unique structural shop identifier string
      const uniqueSuffix = Math.floor(1000 + Math.random() * 9000);
      const generatedShopCode = `RIVO-${uniqueSuffix}`;

      // 4. Insert core vendor record with category_id mapping added
      console.log("Executing Step 2: Inserting Vendor Core Record");
      const { data: vendorData, error: vendorError } = await supabase
        .from("vendors")
        .insert({
          auth_user_id: authData.user.id,
          shop_name: shopName,
          owner_name: ownerName,
          email: email.trim(),
          phone,
          shop_code: generatedShopCode,
          status: "pending",
          category_id: category
        })
        .select()
        .single();

      if (vendorError) {
        console.error("Vendor Table Insertion Error trace:", vendorError);
        throw new Error(`Core vendor record provisioning failed: ${vendorError.message}`);
      }

      // 5. Initialize the secondary profile table including drug licence information
      console.log("Executing Step 3: Inserting Vendor Profile Row");
      const { error: profileError } = await supabase
        .from("vendor_profiles")
        .insert({
          vendor_id: vendorData.id,
          categories: [category],
          address_line1: address,
          store_status: "open",
          drug_license: requiresDrugLicense ? combinedLicenseNumbers : null,
          drug_license_expiry: requiresDrugLicense ? drugLicenseExpiry : null
        });

      if (profileError) {
        console.error("Vendor Profile Table Insertion Error trace:", profileError);
        throw new Error(`Secondary extended profile instantiation failed: ${profileError.message}`);
      }

      // 6. Establish Success State Flags / Subscription Setup
      console.log("Executing Step 4: Registering Free Tier Subscription");
      
      // Save data needed for the registration success view
      setSavedShopName(currentShopName);
      setSavedPhone(currentPhone);
      setSavedLicenseNumbers(combinedLicenseNumbers);
      setShowPremiumCard(requiresDrugLicense);

      setSuccessMessage(`Registration submitted. Your assigned login identifier code is ${generatedShopCode}. Account profile is currently awaiting admin approval.`);
      
      // Clear tracking hooks out of system variables safely
      setShopName("");
      setOwnerName("");
      setEmail("");
      setPhone("");
      setAddress("");
      setCategory("");
      setPassword("");
      setConfirmPassword("");
      setDrugLicenseNumber1("");
      setDrugLicenseNumber2("");
      setDrugLicenseNumber3("");
      setDrugLicenseNumber4("");
      setDrugLicenseNumber5("");
      setDrugLicenseExpiry("");
    } catch (err: any) {
      setError(err.message || "An unexpected system registration variance occurred.");
      console.error("Registration operational trace crash details:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F0FDF4] via-white to-[#EFF6FF] flex items-center justify-center p-4 py-12">
      <div className="w-full max-w-xl">
        {/* Visual Brand Logo Panel */}
        <div className="flex items-center gap-3 justify-center mb-8">
          <div className="w-10 h-10 rounded-xl bg-[#10B981] flex items-center justify-center shadow-lg shadow-[#10B981]/25">
            <Zap className="w-5 h-5 text-white" />
          </div>
          <div>
            <span className="text-2xl font-bold text-[#0F172A] tracking-tight">Rivo</span>
            <p className="text-[11px] text-[#64748B] leading-none mt-0.5">Vendor Portal</p>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-xl shadow-black/5 border border-[#E2E8F0] p-8">
          {successMessage ? (
            <div className="text-center py-6 space-y-4">
              <div className="w-12 h-12 bg-[#ECFDF5] rounded-full flex items-center justify-center mx-auto text-[#10B981]">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h2 className="text-lg font-semibold text-[#0F172A]">Application Received!</h2>
                <p className="text-sm text-[#64748B] max-w-md mx-auto">{successMessage}</p>
              </div>

              {/* Premium Information Card */}
              {showPremiumCard && (
                <div className="mt-6 text-left border border-[#E2E8F0] rounded-xl p-5 bg-[#F8FAFC] shadow-sm">
                  <h3 className="text-sm font-semibold text-[#0F172A] border-b border-[#E2E8F0] pb-2 mb-3">
                    Licence Verification Required
                  </h3>
                  <p className="text-xs text-[#64748B] mb-2 leading-relaxed">
                    Your registration has been submitted successfully.
                  </p>
                  <p className="text-xs text-[#64748B] mb-3 leading-relaxed">
                    Your account is currently <span className="font-semibold text-[#0F172A]">Pending</span>.
                  </p>
                  <p className="text-xs text-[#64748B] mb-3 leading-relaxed">
                    Please send clear photos or scanned copies of your Drug Licence through our official WhatsApp number for manual verification.
                  </p>
                  <p className="text-xs font-medium text-[#0F172A] mb-1">
                    While sending your documents include:
                  </p>
                  <ul className="list-disc pl-4 space-y-1 mb-3 text-xs text-[#64748B]">
                    <li>Shop Name: <span className="font-medium text-[#0F172A]">{savedShopName}</span></li>
                    <li>Registered Mobile Number: <span className="font-medium text-[#0F172A]">{savedPhone}</span></li>
                    <li>Drug Licence Numbers: <span className="font-medium text-[#0F172A]">{savedLicenseNumbers}</span></li>
                  </ul>
                  <p className="text-xs text-[#64748B] italic border-t border-[#E2E8F0] pt-2 mt-2">
                    Your account will be activated after verification by the Rivo team.
                  </p>
                </div>
              )}

              <button
                type="button"
                onClick={onNavigateToLogin}
                className="mt-4 px-6 h-10 rounded-lg bg-[#10B981] hover:bg-[#059669] text-white font-medium text-sm transition-colors shadow-md shadow-[#10B981]/10"
              >
                Go to Login Screen
              </button>
            </div>
          ) : (
            <>
              <div className="mb-6">
                <h1 className="text-xl font-semibold text-[#0F172A]">Create Merchant Account</h1>
                <p className="text-sm text-[#64748B] mt-1">Register your retail location onto the Rivo platform network</p>
              </div>

              <form onSubmit={handleRegister} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-[#0F172A] mb-1.5">Shop Name</label>
                    <input
                      ref={shopNameRef}
                      type="text"
                      value={shopName}
                      onChange={(e) => setShopName(e.target.value)}
                      placeholder="e.g. Fresh Grocery Mart"
                      className="w-full h-10 px-3 rounded-lg border border-[#E2E8F0] bg-[#F8FAFC] text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:border-[#10B981] focus:ring-2 focus:ring-[#10B981]/20 transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#0F172A] mb-1.5">Owner Name</label>
                    <input
                      ref={ownerNameRef}
                      type="text"
                      value={ownerName}
                      onChange={(e) => setOwnerName(e.target.value)}
                      placeholder="e.g. Rahul Sharma"
                      className="w-full h-10 px-3 rounded-lg border border-[#E2E8F0] bg-[#F8FAFC] text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:border-[#10B981] focus:ring-2 focus:ring-[#10B981]/20 transition-all"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-[#0F172A] mb-1.5">Email Address</label>
                    <input
                      ref={emailRef}
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="owner@store.com"
                      className="w-full h-10 px-3 rounded-lg border border-[#E2E8F0] bg-[#F8FAFC] text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:border-[#10B981] focus:ring-2 focus:ring-[#10B981]/20 transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#0F172A] mb-1.5">Phone Number</label>
                    <input
                      ref={phoneRef}
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="e.g. +91 98765 43210"
                      className="w-full h-10 px-3 rounded-lg border border-[#E2E8F0] bg-[#F8FAFC] text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:border-[#10B981] focus:ring-2 focus:ring-[#10B981]/20 transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#0F172A] mb-1.5">
                    Store Category {categoriesLoading && <span className="text-xs text-[#64748B] ml-2 animate-pulse">(Loading...)</span>}
                  </label>
                  <select
                    ref={categoryRef}
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full h-10 px-3 rounded-lg border border-[#E2E8F0] bg-[#F8FAFC] text-[#0F172A] focus:outline-none focus:border-[#10B981] focus:ring-2 focus:ring-[#10B981]/20 transition-all"
                  >
                    <option value="" disabled>Select store category</option>
                    {categories.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Smooth transition container for Drug Licence fields */}
                <div
                  className={`transition-all duration-300 ease-in-out overflow-hidden ${
                    requiresDrugLicense ? "max-h-[600px] opacity-100 mt-4 space-y-4" : "max-h-0 opacity-0 pointer-events-none"
                  }`}
                >
                  <div className="border border-[#E2E8F0] bg-[#F8FAFC] rounded-xl p-4 space-y-4">
                    <h3 className="text-sm font-semibold text-[#0F172A]">Drug Licence Information</h3>
                    
                    <div className="space-y-3">
                      <div>
                        <label className="block text-sm font-medium text-[#0F172A] mb-1.5">Drug Licence Number 1 *</label>
                        <input
                          ref={drugLicenseNumber1Ref}
                          type="text"
                          value={drugLicenseNumber1}
                          onChange={(e) => setDrugLicenseNumber1(e.target.value)}
                          placeholder="Enter Licence Number 1"
                          className="w-full h-10 px-3 rounded-lg border border-[#E2E8F0] bg-white text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:border-[#10B981] focus:ring-2 focus:ring-[#10B981]/20 transition-all"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-[#0F172A] mb-1.5">Drug Licence Number 2</label>
                        <input
                          type="text"
                          value={drugLicenseNumber2}
                          onChange={(e) => setDrugLicenseNumber2(e.target.value)}
                          placeholder="Enter Licence Number 2 (Optional)"
                          className="w-full h-10 px-3 rounded-lg border border-[#E2E8F0] bg-white text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:border-[#10B981] focus:ring-2 focus:ring-[#10B981]/20 transition-all"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-[#0F172A] mb-1.5">Drug Licence Number 3</label>
                        <input
                          type="text"
                          value={drugLicenseNumber3}
                          onChange={(e) => setDrugLicenseNumber3(e.target.value)}
                          placeholder="Enter Licence Number 3 (Optional)"
                          className="w-full h-10 px-3 rounded-lg border border-[#E2E8F0] bg-white text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:border-[#10B981] focus:ring-2 focus:ring-[#10B981]/20 transition-all"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-[#0F172A] mb-1.5">Drug Licence Number 4</label>
                        <input
                          type="text"
                          value={drugLicenseNumber4}
                          onChange={(e) => setDrugLicenseNumber4(e.target.value)}
                          placeholder="Enter Licence Number 4 (Optional)"
                          className="w-full h-10 px-3 rounded-lg border border-[#E2E8F0] bg-white text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:border-[#10B981] focus:ring-2 focus:ring-[#10B981]/20 transition-all"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-[#0F172A] mb-1.5">Drug Licence Number 5</label>
                        <input
                          type="text"
                          value={drugLicenseNumber5}
                          onChange={(e) => setDrugLicenseNumber5(e.target.value)}
                          placeholder="Enter Licence Number 5 (Optional)"
                          className="w-full h-10 px-3 rounded-lg border border-[#E2E8F0] bg-white text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:border-[#10B981] focus:ring-2 focus:ring-[#10B981]/20 transition-all"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-[#0F172A] mb-1.5">Drug Licence Expiry Date *</label>
                        <input
                          ref={drugLicenseExpiryRef}
                          type="date"
                          value={drugLicenseExpiry}
                          onChange={(e) => setDrugLicenseExpiry(e.target.value)}
                          className="w-full h-10 px-3 rounded-lg border border-[#E2E8F0] bg-white text-[#0F172A] focus:outline-none focus:border-[#10B981] focus:ring-2 focus:ring-[#10B981]/20 transition-all"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#0F172A] mb-1.5">Physical Store Address</label>
                  <textarea
                    ref={addressRef}
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Provide full shop layout address details"
                    rows={2}
                    className="w-full p-3 rounded-lg border border-[#E2E8F0] bg-[#F8FAFC] text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:border-[#10B981] focus:ring-2 focus:ring-[#10B981]/20 transition-all resize-none"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-[#0F172A] mb-1.5">Password</label>
                    <div className="relative">
                      <input
                        ref={passwordRef}
                        type={showPassword ? "text" : "password"}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Create complex password"
                        className="w-full h-10 px-3 pr-10 rounded-lg border border-[#E2E8F0] bg-[#F8FAFC] text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:border-[#10B981] focus:ring-2 focus:ring-[#10B981]/20 transition-all"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-[#94A3B8] hover:text-[#64748B] transition-colors"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#0F172A] mb-1.5">Confirm Password</label>
                    <div className="relative">
                      <input
                        ref={confirmPasswordRef}
                        type={showConfirmPassword ? "text" : "password"}
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="Re-enter password string"
                        className="w-full h-10 px-3 pr-10 rounded-lg border border-[#E2E8F0] bg-[#F8FAFC] text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:border-[#10B981] focus:ring-2 focus:ring-[#10B981]/20 transition-all"
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-[#94A3B8] hover:text-[#64748B] transition-colors"
                      >
                        {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </div>

                {error && (
                  <p className="text-sm text-[#EF4444] bg-[#FEF2F2] border border-[#FECACA] rounded-lg px-3 py-2">{error}</p>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full h-10 mt-2 rounded-lg bg-[#10B981] hover:bg-[#059669] text-white font-medium transition-all shadow-lg shadow-[#10B981]/25 hover:shadow-[#10B981]/40 disabled:opacity-60 flex items-center justify-center gap-2"
                >
                  {loading ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : null}
                  Submit Vendor Application
                </button>

                <div className="text-center mt-4">
                  <button
                    type="button"
                    onClick={onNavigateToLogin}
                    className="text-sm text-[#64748B] hover:text-[#10B981] transition-colors"
                  >
                    Already have a merchant account? <span className="text-[#10B981] font-medium hover:underline">Sign In</span>
                  </button>
                </div>
              </form>
            </>
          )}
        </div>

        <p className="text-center text-xs text-[#94A3B8] mt-6">
          Everything Nearby. Delivered Fast. · <span className="text-[#10B981]">Rivo</span> © 2026
        </p>
      </div>
    </div>
  );
}